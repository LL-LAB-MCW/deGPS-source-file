pkgname <- "deGPS"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('deGPS')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("GPSmle.default")
### * GPSmle.default

flush(stderr()); flush(stdout())

### Name: GPSmle.default
### Title: Generalized Poisson Statistical Maximum Likelihood Estimation
###   (default)
### Aliases: GPSmle.default
### Keywords: normalization de-test

### ** Examples

## Not run: 
##D ##Generate Random samples from GP(theta, lambda)
##D examData <- newExampleData(nRNA = 100, groupSize = 2, lambda = 0.9, 
##D theta = 3, ptol = 1e-15)
##D str(examData)
##D 
##D ##Differential Expression Tests for miRNA
##D examRes <- GPSmle(data = examData$data, group = examData$group, method = "GP-Theta", 
##D type = "pvalue", ncpu = 1, geneid = paste("G", 1:100, sep = ""))
##D str(examRes)
##D 
##D topTags(examRes, n = 10, method = "BH")
##D 
##D plot(examRes)
## End(Not run)



cleanEx()
nameEx("bottomlyData")
### * bottomlyData

flush(stderr()); flush(stdout())

### Name: bottomlyData
### Title: A real mouse RNA-seq data set
### Aliases: bottomlyData
### Keywords: bottomly

### ** Examples

## Not run: 
##D ### load required packages
##D 
##D require(edgeR)
##D require(DESeq)
##D require(DESeq2)
##D require(ggplot2)
##D require(gridExtra)
##D require(deGPS)
##D 
##D data(bottomlyData)
##D group <- c(rep(1:2, each = 10), 2)
##D simuData <- as.matrix(bottomlyData[ , -1])
##D 
##D ### apply deGPS on bottomly data
##D bottomlyRes <- deGPS_mRNA(data = simuData, group = group, 
##D ncore = 4, nSubcore = 4, method = "GP-Theta", maxIter = 300)
##D 
##D pvalue <- as.vector(bottomlyRes$pvalue)
##D 
##D ### compare result with edgeR and DESeq, DESeq2
##D 
##D d0 <- DGEList(counts = simuData, group = group)
##D design <- model.matrix(~ group, data = d0$samples)
##D d <- try(calcNormFactors(d0, method = "TMM"))
##D d <- try(estimateGLMCommonDisp(d, design, verbose = TRUE))
##D d <- try(estimateGLMTrendedDisp(d, design))
##D efit <- try(glmQLFTest(d, design, coef = 2))
##D edgeRes <- efit$table$PValue
##D 
##D cds1 <- newCountDataSet(simuData, group)
##D cds2 <- estimateSizeFactors(cds1)
##D cds3 <- try(estimateDispersions(cds2))
##D if("try-error" ##D 
##D if("try-error" ##D 
##D fitType = "local"))
##D 
##D res <- nbinomTest(cds3, 1, 2)
##D deseqRes <- res$pval
##D deseqRes[is.na(deseqRes)] <- 1
##D dds <- DESeqDataSetFromMatrix(countData = simuData,
##D colData = data.frame(group = group),
##D design = ~ group)
##D dds <- DESeq(dds)
##D res <- results(dds)
##D deseq2Res <- res$pvalue
##D deseq2Res[is.na(deseq2Res)] <- 1
##D 
##D ### plot the overlap of DEs
##D pAll <- cbind(pvalue, edgeRes, deseqRes, deseq2Res)
##D pAll <- apply(pAll, 2, p.adjust, method = "BH")
##D 
##D overLapTemp <- overLapTemp1 <- matrix(NA, ncol(pAll), ncol(pAll))
##D 
##D for(ii in 1:ncol(pAll)){
##D for(jj in 1:ncol(pAll)){
##D overLapTemp[ii, jj] <- sum(pAll[ , ii] < 0.05 & pAll[ , jj] < 0.05) / sum(pAll[ , ii] < 0.05)
##D }
##D }
##D 
##D for(ii in 1:ncol(pAll)){
##D for(jj in 1:ncol(pAll)){
##D overLapTemp1[ii, jj] <- sum(pAll[ , ii] < 0.05 & pAll[, jj] < 0.05)
##D }
##D }
##D 
##D dimnames(overLapTemp) <- dimnames(overLapTemp1) <- list(c("deGPS", "edgeR", "DESeq", "DESeq2"), c("deGPS", "edgeR", "DESeq", "DESeq2"))
##D 
##D jpeg("bottomlyOverLap.jpg", width = 1600, height = 700)
##D 
##D a <- levelplot(overLapTemp, xlab = "", ylab = "", main = list("Overlap Proportion", cex = 2), 
##D scale = list(cex = 1.3), 
##D colorkey = list(labels = list(cex = 1.2)), 
##D panel=function(...) {
##D arg <- list(...)
##D panel.levelplot(...)
##D panel.text(rep(1:nrow(overLapTemp), ncol(overLapTemp)), 
##D rep(1:ncol(overLapTemp), each = nrow(overLapTemp)), round(as.vector(overLapTemp), 2), cex = 1.5)}
##D )
##D 
##D b <- levelplot(overLapTemp1, xlab = "", ylab = "", main = list("Overlap Number", cex = 2), 
##D scale = list(cex = 1.3), 
##D colorkey = list(labels = list(cex = 1.2)), 
##D panel=function(...) {
##D arg <- list(...)
##D panel.levelplot(...)
##D panel.text(rep(1:nrow(overLapTemp1), ncol(overLapTemp1)), 
##D rep(1:ncol(overLapTemp1), each = nrow(overLapTemp1)), as.vector(overLapTemp1), cex = 1.5)}
##D )
##D grid.arrange(a, b, ncol=2)
##D dev.off()
## End(Not run)



cleanEx()
nameEx("deGPS-package")
### * deGPS-package

flush(stderr()); flush(stdout())

### Name: deGPS-package
### Title: Normalization and Two-group Differential Expression Test for
###   RNA-seq Data
### Aliases: deGPS-package deGPS
### Keywords: GP RNA-seq DifferentialExpression

### ** Examples

## Not run: 
##D ###Analyze real RNA-seq data
##D data(bottomlyData)
##D group <- c(rep(1:2, each = 10), 2)
##D simuData <- as.matrix(bottomlyData[ , -1])
##D dimnames(simuData)[[1]] <- as.character(bottomlyData$gene) 
##D 
##D ### apply deGPS on bottomly data
##D bottomlyRes <- deGPS_mRNA(data = simuData, group = group, 
##D ncore = 4, nSubcore = 4, method = "GP-Theta", maxIter = 150)
##D 
##D pvalue <- as.vector(bottomlyRes$pvalue)
##D adj.p <- p.adjust(pvalue, method = "BH")
##D topTags(pvalue)
##D 
##D ##Generate Random samples from GP(theta, lambda)
##D examData <- newExampleData(nRNA = 100, groupSize = 6, lambda = 0.9, 
##D theta = 3, ptol = 1e-15)
##D str(examData)
##D 
##D ##Differential Expression Tests
##D examRes <- deGPS_mRNA(data = examData$data, group = examData$group, 
##D method = "GP-Theta", nSubcore = 2, ncore = 2, geneid = paste("G", 1:100, sep = ""))
##D str(examRes)
##D 
##D ###Generate simulated RNA-seq data from compcodeR package
##D require(compcodeR)
##D 
##D samples.per.cond <- 5
##D random.outlier.high.prob <- 0.1
##D n.vars <- 10000
##D 
##D examData <- generateSyntheticData(dataset = "simuData",
##D n.vars = n.vars, samples.per.cond = samples.per.cond, n.diffexp = floor(n.vars * 0.1),
##D repl.id = 1, seqdepth = 1e+07, fraction.upregulated = 0.5,
##D between.group.diffdisp = FALSE, filter.threshold.total = 1,
##D filter.threshold.mediancpm = 0, fraction.non.overdispersed = 0,
##D random.outlier.high.prob = random.outlier.high.prob,
##D output.file = "simuData_repl1.rds")
##D 
##D group <- examData@sample.annotations$condition
##D 
##D examRes <- deGPS_mRNA(data = examData@count.matrix, group = group, 
##D method = "GP-Theta", nSubcore = 2, ncore = 2, geneid = paste("G", 1:n.vars, sep = ""))
##D str(examRes)
##D 
## End(Not run)



cleanEx()
nameEx("deGPS_mRNA")
### * deGPS_mRNA

flush(stderr()); flush(stdout())

### Name: deGPS_mRNA
### Title: Normalization and Two-group Differential Expression Test for
###   mRNA Read Count Data
### Aliases: deGPS_mRNA
### Keywords: deGPS mRNA

### ** Examples

## Not run: 
##D ### See the example in "bottomlyData" for real data analysis and the comparison between deGPS 
##D ### and other widely-used methods
##D 
##D ##Generate Random samples from GP(theta, lambda)
##D examData <- newExampleData(nRNA = 100, groupSize = 6, lambda = 0.9, 
##D theta = 3, ptol = 1e-15)
##D str(examData)
##D 
##D ##Differential Expression Tests
##D examRes <- deGPS_mRNA(data = examData$data, group = examData$group, 
##D method = "GP-Theta", nSubcore = 2, ncore = 2, geneid = paste("G", 1:100, sep = ""))
##D str(examRes)
##D topTags(examRes, n = 10, method = "BH")
##D 
##D ###Generate simulated RNA-seq data from compcodeR package
##D require(compcodeR)
##D 
##D samples.per.cond <- 5
##D random.outlier.high.prob <- 0.1
##D n.vars <- 10000
##D 
##D examData <- generateSyntheticData(dataset = "simuData",
##D n.vars = n.vars, samples.per.cond = samples.per.cond, n.diffexp = floor(n.vars * 0.1),
##D repl.id = 1, seqdepth = 1e+07, fraction.upregulated = 0.5,
##D between.group.diffdisp = FALSE, filter.threshold.total = 1,
##D filter.threshold.mediancpm = 0, fraction.non.overdispersed = 0,
##D random.outlier.high.prob = random.outlier.high.prob,
##D output.file = "simuData_repl1.rds")
##D 
##D group <- examData@sample.annotations$condition
##D 
##D examRes <- deGPS_mRNA(data = examData@count.matrix, group = group, 
##D method = "GP-Theta", nSubcore = 2, ncore = 2, geneid = paste("G", 1:n.vars, sep = ""))
##D str(examRes)
##D topTags(examRes, n = 10, method = "BH")
##D 
## End(Not run)



cleanEx()
nameEx("newExampleData")
### * newExampleData

flush(stderr()); flush(stdout())

### Name: newExampleData
### Title: Generate example data for GPSmle and deGPS_mRNA
### Aliases: newExampleData
### Keywords: random gp

### ** Examples

## Not run: 
##D ####Different Lambda and Theta for Two Groups
##D examData <- newExampleData(nRNA = 100, groupSize = 2, lambda = c(0.5, 0.9), 
##D theta = c(3, 10), ptol = 1e-15)
##D 
##D ####Same Lambda and Theta for Two Groups
##D examData <- newExampleData(nRNA = 100, groupSize = 2, lambda = 0.9, theta = 3, 
##D ptol = 1e-15)
##D 
##D 
##D ###Generate simulated RNA-seq data from compcodeR package
##D require(compcodeR)
##D 
##D samples.per.cond <- 5
##D random.outlier.high.prob <- 0.1
##D n.vars <- 10000
##D 
##D examData <- generateSyntheticData(dataset = "simuData",
##D n.vars = n.vars, samples.per.cond = samples.per.cond, n.diffexp = floor(n.vars * 0.1),
##D repl.id = 1, seqdepth = 1e+07, fraction.upregulated = 0.5,
##D between.group.diffdisp = FALSE, filter.threshold.total = 1,
##D filter.threshold.mediancpm = 0, fraction.non.overdispersed = 0,
##D random.outlier.high.prob = random.outlier.high.prob,
##D output.file = "simuData_repl1.rds")
## End(Not run)



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
